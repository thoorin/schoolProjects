package com.company;

import java.math.BigInteger;

public class Main {

    public static void main(String[] args) {
        //vytvoření oken pro zašifrování a dešifrování
        new Cipher(100,100);
        new Decipher( 700, 100);
    }
}
